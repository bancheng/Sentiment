###HTML files.

_index.html_ is a sample generated file by this testsuite. 

_style.css_ should be placed in the html directory in which _index.html_ will be placed in order to visualize the test results in a browser.
